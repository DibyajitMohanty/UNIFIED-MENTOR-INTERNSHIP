// app.js
let currentInput = '';
let memory = 0;
const display = document.getElementById('display');

function appendValue(value) {
  if (currentInput.length < 16) {
    currentInput += value;
    updateDisplay(currentInput);
  }
}

function updateDisplay(value) {
  display.textContent = value || '0';
}

function clearDisplay() {
  currentInput = '';
  updateDisplay('0');
}

function calculate() {
  try {
    const result = eval(currentInput); // Evaluate the expression
    if (!isFinite(result)) throw new Error('Math Error');
    currentInput = result.toString();
    updateDisplay(currentInput);
  } catch (error) {
    updateDisplay('Error');
    setTimeout(clearDisplay, 1500);
  }
}

function memoryAdd() {
  memory += parseFloat(currentInput || '0');
  alert(`Memory updated: ${memory}`);
}

function memorySubtract() {
  memory -= parseFloat(currentInput || '0');
  alert(`Memory updated: ${memory}`);
}

function memoryRecall() {
  currentInput = memory.toString();
  updateDisplay(currentInput);
}

function memoryClear() {
  memory = 0;
  alert('Memory cleared');
}
