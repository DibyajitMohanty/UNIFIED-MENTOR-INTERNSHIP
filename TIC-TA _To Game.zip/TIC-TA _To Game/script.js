const board = document.getElementById('board');
const statusDisplay = document.getElementById('game-status');
const resetButton = document.getElementById('reset-button');

let currentPlayer = 'X';
let gameState = Array(9).fill(null);
let isGameActive = true;

const winningConditions = [
    [0, 1, 2],
    [3, 4, 5],
    [6, 7, 8],
    [0, 3, 6],
    [1, 4, 7],
    [2, 5, 8],
    [0, 4, 8],
    [2, 4, 6]
];

const updateStatus = (message) => {
    statusDisplay.textContent = message;
};

const checkWinner = () => {
    for (const condition of winningConditions) {
        const [a, b, c] = condition;
        if (gameState[a] && gameState[a] === gameState[b] && gameState[a] === gameState[c]) {
            return gameState[a];
        }
    }
    return gameState.includes(null) ? null : 'Tie';
};

const handleClick = (event) => {
    const cell = event.target;
    const cellIndex = cell.getAttribute('data-index');

    if (gameState[cellIndex] || !isGameActive) {
        return;
    }

    gameState[cellIndex] = currentPlayer;
    cell.textContent = currentPlayer;

    const winner = checkWinner();
    if (winner) {
        isGameActive = false;
        if (winner === 'Tie') {
            updateStatus("It's a Tie!");
        } else {
            updateStatus(`Player ${winner} Wins!`);
        }
    } else {
        currentPlayer = currentPlayer === 'X' ? 'O' : 'X';
        updateStatus(`Player ${currentPlayer}'s Turn`);
    }
};

const resetGame = () => {
    gameState.fill(null);
    currentPlayer = 'X';
    isGameActive = true;
    Array.from(board.children).forEach((cell) => (cell.textContent = ''));
    updateStatus("Player X's Turn");
};

board.addEventListener('click', handleClick);
resetButton.addEventListener('click', resetGame);
