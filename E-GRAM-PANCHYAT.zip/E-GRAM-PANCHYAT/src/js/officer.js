import { createService, updateService, deleteService, getAllServices, updateApplicationStatus } from './database.js';

export async function createNewService(serviceData) {
    try {
        return await createService(serviceData);
    } catch (error) {
        console.error('Error creating new service:', error);
        throw error;
    }
}

export async function updateExistingService(serviceId, serviceData) {
    try {
        await updateService(serviceId, serviceData);
    } catch (error) {
        console.error('Error updating service:', error);
        throw error;
    }
}

export async function removeService(serviceId) {
    try {
        await deleteService(serviceId);
    } catch (error) {
        console.error('Error removing service:', error);
        throw error;
    }
}

export async function getServices() {
    try {
        return await getAllServices();
    } catch (error) {
        console.error('Error getting services:', error);
        throw error;
    }
}

export async function updateApplicationStatus(applicationId, status) {
    try {
        await updateApplicationStatus(applicationId, status);
    } catch (error) {
        console.error('Error updating application status:', error);
        throw error;
    }
}

