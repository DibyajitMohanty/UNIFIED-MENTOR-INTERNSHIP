import { getFirestore, collection, query, where, getDocs, updateDoc, doc } from 'firebase/firestore';
import { getAllServices, updateApplicationStatus } from './database.js';

const db = getFirestore();

export async function getAssignedApplications(staffId) {
    try {
        const q = query(collection(db, 'applications'), where('assignedTo', '==', staffId));
        const querySnapshot = await getDocs(q);
        return querySnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
    } catch (error) {
        console.error('Error getting assigned applications:', error);
        throw error;
    }
}

export async function updateApplication(applicationId, status) {
    try {
        await updateApplicationStatus(applicationId, status);
    } catch (error) {
        console.error('Error updating application:', error);
        throw error;
    }
}

export async function viewServices() {
    try {
        return await getAllServices();
    } catch (error) {
        console.error('Error viewing services:', error);
        throw error;
    }
}

