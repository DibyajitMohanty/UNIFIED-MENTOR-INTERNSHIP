import { getAuth } from 'firebase/auth';
import { getFirestore, doc, getDoc, updateDoc } from 'firebase/firestore';
import { createApplication, getUserApplications } from './database.js';

const auth = getAuth();
const db = getFirestore();

export async function getUserProfile() {
    const user = auth.currentUser;
    if (user) {
        const userDoc = await getDoc(doc(db, 'users', user.uid));
        if (userDoc.exists()) {
            return userDoc.data();
        } else {
            throw new Error('User profile not found');
        }
    } else {
        throw new Error('No user is signed in');
    }
}

export async function updateUserProfile(profileData) {
    const user = auth.currentUser;
    if (user) {
        const userRef = doc(db, 'users', user.uid);
        await updateDoc(userRef, profileData);
    } else {
        throw new Error('No user is signed in');
    }
}

export async function applyForService(serviceId) {
    const user = auth.currentUser;
    if (user) {
        const applicationData = {
            userId: user.uid,
            serviceId: serviceId,
            status: 'pending',
            createdAt: new Date()
        };
        return await createApplication(applicationData);
    } else {
        throw new Error('No user is signed in');
    }
}

export async function getMyApplications() {
    const user = auth.currentUser;
    if (user) {
        return await getUserApplications(user.uid);
    } else {
        throw new Error('No user is signed in');
    }
}

