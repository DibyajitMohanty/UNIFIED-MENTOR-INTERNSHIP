import { initializeApp } from 'firebase/app';
import { getAuth, onAuthStateChanged } from 'firebase/auth';
import { getFirestore } from 'firebase/firestore';
import { renderHeader } from './components/header.js';
import { renderFooter } from './components/footer.js';
import { renderLoginForm } from './components/login.js';
import { renderRegisterForm } from './components/register.js';
import { renderServices } from './components/services.js';
import { renderApplicationStatus } from './components/application.js';

// Firebase configuration
const firebaseConfig = {
    // Your Firebase config here
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getFirestore(app);

// Global state
let currentUser = null;
let userRole = null;

// Main function to initialize the app
function initApp() {
    renderHeader();
    renderFooter();

    // Check authentication state
    onAuthStateChanged(auth, (user) => {
        if (user) {
            currentUser = user;
            checkUserRole(user.uid);
        } else {
            currentUser = null;
            userRole = null;
            renderLoginForm();
        }
    });

    // Add event listeners for navigation
    document.addEventListener('click', (e) => {
        if (e.target.matches('[data-link]')) {
            e.preventDefault();
            navigateTo(e.target.getAttribute('data-link'));
        }
    });
}

// Function to check user role
async function checkUserRole(uid) {
    const userDoc = await db.collection('users').doc(uid).get();
    if (userDoc.exists) {
        userRole = userDoc.data().role;
        renderDashboard();
    } else {
        console.error('User document does not exist');
        auth.signOut();
    }
}

// Function to render dashboard based on user role
function renderDashboard() {
    const mainContent = document.getElementById('main-content');
    mainContent.innerHTML = '';

    switch (userRole) {
        case 'user':
            renderServices();
            break;
        case 'staff':
            // Render staff dashboard
            break;
        case 'officer':
            // Render officer dashboard
            break;
        default:
            console.error('Unknown user role');
            auth.signOut();
    }
}

// Navigation function
function navigateTo(route) {
    switch (route) {
        case 'login':
            renderLoginForm();
            break;
        case 'register':
            renderRegisterForm();
            break;
        case 'services':
            renderServices();
            break;
        case 'application-status':
            renderApplicationStatus();
            break;
        case 'logout':
            auth.signOut();
            break;
        default:
            console.error('Unknown route');
    }
}

// Initialize the app
initApp();

