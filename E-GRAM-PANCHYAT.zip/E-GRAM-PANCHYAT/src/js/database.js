import { getFirestore, collection, addDoc, updateDoc, deleteDoc, doc, getDoc, getDocs, query, where } from 'firebase/firestore';

const db = getFirestore();

export async function createService(serviceData) {
    try {
        const docRef = await addDoc(collection(db, 'services'), serviceData);
        return docRef.id;
    } catch (error) {
        console.error('Error creating service:', error);
        throw error;
    }
}

export async function updateService(serviceId, serviceData) {
    try {
        const serviceRef = doc(db, 'services', serviceId);
        await updateDoc(serviceRef, serviceData);
    } catch (error) {
        console.error('Error updating service:', error);
        throw error;
    }
}

export async function deleteService(serviceId) {
    try {
        await deleteDoc(doc(db, 'services', serviceId));
    } catch (error) {
        console.error('Error deleting service:', error);
        throw error;
    }
}

export async function getService(serviceId) {
    try {
        const serviceDoc = await getDoc(doc(db, 'services', serviceId));
        if (serviceDoc.exists()) {
            return serviceDoc.data();
        } else {
            throw new Error('Service not found');
        }
    } catch (error) {
        console.error('Error getting service:', error);
        throw error;
    }
}

export async function getAllServices() {
    try {
        const querySnapshot = await getDocs(collection(db, 'services'));
        return querySnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
    } catch (error) {
        console.error('Error getting all services:', error);
        throw error;
    }
}

export async function createApplication(applicationData) {
    try {
        const docRef = await addDoc(collection(db, 'applications'), applicationData);
        return docRef.id;
    } catch (error) {
        console.error('Error creating application:', error);
        throw error;
    }
}

export async function updateApplicationStatus(applicationId, status) {
    try {
        const applicationRef = doc(db, 'applications', applicationId);
        await updateDoc(applicationRef, { status: status });
    } catch (error) {
        console.error('Error updating application status:', error);
        throw error;
    }
}

export async function getUserApplications(userId) {
    try {
        const q = query(collection(db, 'applications'), where('userId', '==', userId));
        const querySnapshot = await getDocs(q);
        return querySnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
    } catch (error) {
        console.error('Error getting user applications:', error);
        throw error;
    }
}

