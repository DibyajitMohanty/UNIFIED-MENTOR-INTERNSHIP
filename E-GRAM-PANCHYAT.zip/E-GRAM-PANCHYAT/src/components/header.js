import { getAuth, onAuthStateChanged } from 'firebase/auth';
import { getFirestore, doc, getDoc } from 'firebase/firestore';

const auth = getAuth();
const db = getFirestore();

export function renderHeader() {
    const headerElement = document.getElementById('header');
    
    onAuthStateChanged(auth, async (user) => {
        if (user) {
            const userDoc = await getDoc(doc(db, 'users', user.uid));
            const role = userDoc.data().role;
            headerElement.innerHTML = `
                <nav>
                    <ul>
                        <li><a href="#" data-link="home">Home</a></li>
                        ${role === 'user' ? `
                            <li><a href="#" data-link="services">Services</a></li>
                            <li><a href="#" data-link="application-status">My Applications</a></li>
                            <li><a href="#" data-link="profile">My Profile</a></li>
                        ` : ''}
                        ${role === 'staff' ? `
                            <li><a href="#" data-link="assigned-applications">Assigned Applications</a></li>
                        ` : ''}
                        ${role === 'officer' ? `
                            <li><a href="#" data-link="manage-services">Manage Services</a></li>
                            <li><a href="#" data-link="manage-applications">Manage Applications</a></li>
                        ` : ''}
                        <li><a href="#" data-link="logout">Logout</a></li>
                    </ul>
                </nav>
            `;
        } else {
            headerElement.innerHTML = `
                <nav>
                    <ul>
                        <li><a href="#" data-link="home">Home</a></li>
                        <li><a href="#" data-link="login">Login</a></li>
                        <li><a href="#" data-link="register">Register</a></li>
                    </ul>
                </nav>
            `;
        }
    });
}

