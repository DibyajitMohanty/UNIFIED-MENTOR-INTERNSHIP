import { getAllServices } from '../js/database.js';
import { applyForService } from '../js/user.js';

export async function renderServices() {
    const mainContent = document.getElementById('main-content');
    mainContent.innerHTML = '<h2>Available Services</h2>';

    try {
        const services = await getAllServices();
        const servicesList = document.createElement('ul');
        services.forEach(service => {
            const listItem = document.createElement('li');
            listItem.innerHTML = `
                <h3>${service.name}</h3>
                <p>${service.description}</p>
                <button class="btn apply-btn" data-service-id="${service.id}">Apply</button>
            `;
            servicesList.appendChild(listItem);
        });
        mainContent.appendChild(servicesList);

        // Add event listeners to apply buttons
        document.querySelectorAll('.apply-btn').forEach(button => {
            button.addEventListener('click', async (e) => {
                const serviceId = e.target.getAttribute('data-service-id');
                try {
                    await applyForService(serviceId);
                    alert('Application submitted successfully!');
                } catch (error) {
                    console.error('Error applying for service:', error);
                    alert('Failed to submit application. Please try again.');
                }
            });
        });
    } catch (error) {
        console.error('Error rendering services:', error);
        mainContent.innerHTML += '<p>Error loading services. Please try again later.</p>';
    }
}

