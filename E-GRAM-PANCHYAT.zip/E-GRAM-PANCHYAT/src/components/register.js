import { registerUser } from '../js/auth.js';

export function renderRegisterForm() {
    const mainContent = document.getElementById('main-content');
    mainContent.innerHTML = `
        <div class="form-container">
            <h2>Register</h2>
            <form id="register-form">
                <div class="form-group">
                    <label for="email">Email:</label>
                    <input type="email" id="email" required>
                </div>
                <div class="form-group">
                    <label for="password">Password:</label>
                    <input type="password" id="password" required>
                </div>
                <div class="form-group">
                    <label for="role">Role:</label>
                    <select id="role" required>
                        <option value="user">User</option>
                        <option value="staff">Staff</option>
                        <option value="officer">Officer</option>
                    </select>
                </div>
                <button type="submit" class="btn">Register</button>
            </form>
        </div>
    `;

    document.getElementById('register-form').addEventListener('submit', async (e) => {
        e.preventDefault();
        const email = document.getElementById('email').value;
        const password = document.getElementById('password').value;
        const role = document.getElementById('role').value;
        try {
            await registerUser(email, password, role);
            alert('Registration successful. Please log in.');
            // Redirect to login page or update UI
        } catch (error) {
            console.error('Registration error:', error);
            alert('Registration failed. Please try again.');
        }
    });
}

