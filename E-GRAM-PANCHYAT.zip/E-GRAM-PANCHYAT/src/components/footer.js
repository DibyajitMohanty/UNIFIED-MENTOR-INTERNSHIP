export function renderFooter() {
    const footerElement = document.getElementById('footer');
    footerElement.innerHTML = `
        <p>&copy; 2023 Digital E Gram Panchayat. All rights reserved.</p>
    `;
}

