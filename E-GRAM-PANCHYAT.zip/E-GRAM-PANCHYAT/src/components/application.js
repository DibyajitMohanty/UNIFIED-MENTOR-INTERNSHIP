import { getMyApplications } from '../js/user.js';

export async function renderApplicationStatus() {
    const mainContent = document.getElementById('main-content');
    mainContent.innerHTML = '<h2>My Applications</h2>';

    try {
        const applications = await getMyApplications();
        if (applications.length === 0) {
            mainContent.innerHTML += '<p>You have no applications.</p>';
        } else {
            const table = document.createElement('table');
            table.innerHTML = `
                <thead>
                    <tr>
                        <th>Service</th>
                        <th>Status</th>
                        <th>Applied Date</th>
                    </tr>
                </thead>
                <tbody>
                    ${applications.map(app => `
                        <tr>
                            <td>${app.serviceId}</td>
                            <td>${app.status}</td>
                            <td>${new Date(app.createdAt.toDate()).toLocaleDateString()}</td>
                        </tr>
                    `).join('')}
                </tbody>
            `;
            mainContent.appendChild(table);
        }
    } catch (error) {
        console.error('Error rendering application status:', error);
        mainContent.innerHTML += '<p>Error loading applications. Please try again later.</p>';
    }
}

