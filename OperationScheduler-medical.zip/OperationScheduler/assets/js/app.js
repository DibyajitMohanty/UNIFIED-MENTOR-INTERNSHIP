// Firebase imports
import { auth, db } from "../../firebase-config.js";
import { createUserWithEmailAndPassword, signInWithEmailAndPassword } from "https://www.gstatic.com/firebasejs/9.15.0/firebase-auth.js";
import { collection, addDoc, getDocs } from "https://www.gstatic.com/firebasejs/9.15.0/firebase-firestore.js";

// User Registration Logic
const userRegisterForm = document.getElementById("userRegisterForm");
if (userRegisterForm) {
  userRegisterForm.addEventListener("submit", async (e) => {
    e.preventDefault();
    const name = e.target.name.value;
    const email = e.target.email.value;
    const password = e.target.password.value;

    try {
      const userCredential = await createUserWithEmailAndPassword(auth, email, password);
      await addDoc(collection(db, "users"), { name, email, uid: userCredential.user.uid });
      alert("Registration Successful");
      window.location.href = "login.html";
    } catch (error) {
      document.getElementById("errorMessage").innerText = error.message;
    }
  });
}

// User Login Logic
const userLoginForm = document.getElementById("userLoginForm");
if (userLoginForm) {
  userLoginForm.addEventListener("submit", async (e) => {
    e.preventDefault();
    const email = e.target.email.value;
    const password = e.target.password.value;

    try {
      await signInWithEmailAndPassword(auth, email, password);
      alert("Login Successful");
      window.location.href = "dashboard.html";
    } catch (error) {
      document.getElementById("errorMessage").innerText = error.message;
    }
  });
}

// Fetch Doctors List (for User)
const doctorList = document.getElementById("doctorList");
const fetchDoctors = async () => {
  const doctorsSnapshot = await getDocs(collection(db, "doctors"));
  doctorsSnapshot.forEach((doc) => {
    const doctor = doc.data();
    doctorList.innerHTML += `<li>${doctor.name} - ${doctor.specialization}</li>`;
  });
};

if (doctorList) fetchDoctors();

// Fetch Surgeries List (for User)
const surgeryList = document.getElementById("surgeryList");
const fetchSurgeries = async () => {
  const surgeriesSnapshot = await getDocs(collection(db, "surgeries"));
  surgeriesSnapshot.forEach((doc) => {
    const surgery = doc.data();
    surgeryList.innerHTML += `<li>${surgery.patient} - ${surgery.doctor} - ${surgery.date} - ${surgery.time}</li>`;
  });
};

if (surgeryList) fetchSurgeries();
