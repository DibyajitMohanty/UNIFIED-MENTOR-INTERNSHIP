// Firebase Initialization
import { initializeApp } from "https://www.gstatic.com/firebasejs/9.15.0/firebase-app.js";
import { getAuth } from "https://www.gstatic.com/firebasejs/9.15.0/firebase-auth.js";
import { getFirestore } from "https://www.gstatic.com/firebasejs/9.15.0/firebase-firestore.js";

const firebaseConfig = {
    apiKey: "AIzaSyAQr7Pm_bETr9v81458_AmFeUIwUJOU598",
    authDomain: "operationscheduler-ab43b.firebaseapp.com",
    projectId: "operationscheduler-ab43b",
    storageBucket: "operationscheduler-ab43b.firebasestorage.app",
    messagingSenderId: "4975642134",
    appId: "1:4975642134:web:b5bdcbd4f85e2280311737",
    measurementId: "G-SJHEH759PP"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const db = getFirestore(app);
